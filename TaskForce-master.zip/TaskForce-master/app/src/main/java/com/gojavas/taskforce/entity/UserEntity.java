package com.gojavas.taskforce.entity;

/**
 * Created by GJS280 on 15/4/2015.
 */
public class UserEntity {

    private String sr;
    private String emp_code;
    private String username;
    private String password;
    private String firstname;
    private String city;
    private String branch;
    private String imei_no;
    private String mobile_no;
    private String datetime;

    public String getsr() {
        return sr;
    }

    public void setsr(String sr) {
        this.sr = sr;
    }

    public String getemp_code() {
        return emp_code;
    }

    public void setemp_code(String emp_code) {
        this.emp_code = emp_code;
    }

    public String getusername() {
        return username;
    }

    public void setusername(String username) {
        this.username = username;
    }

    public String getpassword() {
        return password;
    }

    public void setpassword(String password) {
        this.password = password;
    }

    public String getfirstname() {
        return firstname;
    }

    public void setfirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getcity() {
        return city;
    }

    public void setcity(String city) {
        this.city = city;
    }

    public String getbranch() {
        return branch;
    }

    public void setbranch(String branch) {
        this.branch = branch;
    }

    public String getimei_no() {
        return imei_no;
    }

    public void setimei_no(String imei_no) {
        this.imei_no = imei_no;
    }

    public String getmobile_no() {
        return mobile_no;
    }

    public void setmobile_no(String mobile_no) {
        this.mobile_no = mobile_no;
    }

    public String getdatetime() {
        return datetime;
    }

    public void setdatetime(String datetime) {
        this.datetime = datetime;
    }
}
