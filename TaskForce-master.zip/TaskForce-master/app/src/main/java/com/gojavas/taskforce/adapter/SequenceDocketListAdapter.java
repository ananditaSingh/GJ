package com.gojavas.taskforce.adapter;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.gojavas.taskforce.R;
import com.gojavas.taskforce.entity.DrsEntity;
import com.gojavas.taskforce.entity.JobSetting;

import java.util.ArrayList;
import java.util.Locale;

/**
 * Created by GJS280 on 20/4/2015.
 */
public class SequenceDocketListAdapter extends BaseAdapter {

    private Context mContext;
    private ArrayList<DrsEntity> mDocketList;
    private ArrayList<DrsEntity> mDocketListFilter=new ArrayList<>();
    private ArrayList<JobSetting> mJobSettingList;
    private String mType = "";

    public SequenceDocketListAdapter() {}

    public SequenceDocketListAdapter(Context context, ArrayList<DrsEntity> docketList, ArrayList<JobSetting> jobList, String type){
        this.mContext = context;
        this.mDocketList = docketList;
        this.mJobSettingList = jobList;
        mDocketListFilter.addAll(docketList);
        this.mType = type;
    }

    @Override
    public int getCount() {
        return mDocketList.size();
    }

    @Override
    public Object getItem(int position) {
        return mDocketList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder {
        TextView mDocketNumber;
        TextView mDocketCustomerName;
        TextView mDocketCustomerAddress;
        TextView mDocketStatus;
        TextView mDocketPosition;
        TextView mDocketAttempt;
    }

    @Override
    public View getView(final int position, View view, ViewGroup viewGroup) {
        ViewHolder holder = null;
        if (view == null) {
            holder = new ViewHolder();
            LayoutInflater mInflater = (LayoutInflater) mContext.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
            view = mInflater.inflate(R.layout.item_list_sequence_docket, null);

            holder.mDocketNumber =  (TextView) view.findViewById(R.id.item_docket_number);
            holder.mDocketCustomerName = (TextView)  view.findViewById(R.id.item_customer_name);
            holder.mDocketCustomerAddress = (TextView)  view.findViewById(R.id.item_customer_address);
            holder.mDocketStatus = (TextView)  view.findViewById(R.id.item_docket_status);
            holder.mDocketPosition = (TextView) view.findViewById(R.id.item_docket_position);
            holder.mDocketAttempt = (TextView) view.findViewById(R.id.item_docket_attempt);

            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }

        DrsEntity entity = mDocketList.get(position);
        holder.mDocketNumber.setText(entity.getdocketno());
        holder.mDocketCustomerName.setText(entity.getcsgenm());
        holder.mDocketCustomerAddress.setText(entity.getcsgeaddr());
        String jobType = entity.getjobtype();
        String attempt = entity.getattempt();
        holder.mDocketAttempt.setText("Attempt " + attempt);
        int size = mJobSettingList.size();
        for(int i=0; i<mJobSettingList.size(); i++) {
            JobSetting job = mJobSettingList.get(i);
            String type = job.getJobType();
            if(type.equalsIgnoreCase(jobType)) {
                String identifier = job.getIdentifier();
                String color = job.getColor();
                holder.mDocketStatus.setText(identifier);
                holder.mDocketStatus.setTextColor(Color.parseColor(color));
                break;
            }
        }

        if(mType.equalsIgnoreCase("Tab")) {
            holder.mDocketPosition.setVisibility(View.GONE);
        } else {
            int pos = entity.getposition();
            if(pos == 0) {
                holder.mDocketPosition.setVisibility(View.GONE);
            } else {
                holder.mDocketPosition.setText("POS: " + pos);
                holder.mDocketPosition.setVisibility(View.VISIBLE);
            }
        }

        return view;
    }

    // Filter Class
    public void filter(String searchText) {
        searchText = searchText.toLowerCase(Locale.getDefault());
        mDocketList.clear();
        if (searchText.length() == 0) {
            mDocketList.addAll(mDocketListFilter);
        } else {
            for (DrsEntity entity : mDocketListFilter) {
                // search both docket no and customer name
                if (entity.getdocketno().toLowerCase(Locale.getDefault()).contains(searchText) ||
                        entity.getcsgenm().toLowerCase(Locale.getDefault()).contains(searchText)) {
                    mDocketList.add(entity);
                }
            }
        }
        notifyDataSetChanged();
    }
}
