package com.gojavas.taskforce.entity;

/**
 * Created by GJS280 on 14/5/2015.
 */
public class SlabEntity {

    private String sr;
    private String drs_no;
    private String docket_no;
    private String slabfrom_to;
    private String slab_rate;

    public String getsr() {
        return sr;
    }

    public void setsr(String sr) {
        this.sr = sr;
    }

    public String getdrs_no() {
        return drs_no;
    }

    public void setdrs_no(String drs_no) {
        this.drs_no = drs_no;
    }

    public String getdocket_no() {
        return docket_no;
    }

    public void setdocket_no(String docket_no) {
        this.docket_no = docket_no;
    }

    public String getslabfrom_to() {
        return slabfrom_to;
    }

    public void setslabfrom_to(String slabfrom_to) {
        this.slabfrom_to = slabfrom_to;
    }

    public String getslab_rate() {
        return slab_rate;
    }

    public void setslab_rate(String slab_rate) {
        this.slab_rate = slab_rate;
    }
}
