package com.gojavas.taskforce.entity;

/**
 * Created by gjs331 on 5/15/2015.
 */
public class StataticsEntity {

    String value;
    String title;
    int imageIcon;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getImageIcon() {
        return imageIcon;
    }

    public void setImageIcon(int imageIcon) {
        this.imageIcon = imageIcon;
    }
}
