package com.gojavas.taskforce.ui.activity;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.crittercism.app.Crittercism;
import com.ezetap.sdk.AppConstants;
import com.ezetap.sdk.EzeConstants;
import com.ezetap.sdk.EzetapPayApis;
import com.gojavas.taskforce.R;
import com.gojavas.taskforce.database.DatabaseHelper;
import com.gojavas.taskforce.database.DrsHelper;
import com.gojavas.taskforce.gcm.QuickstartPreferences;
import com.gojavas.taskforce.gcm.RegistrationIntentService;
import com.gojavas.taskforce.manager.BackupManager;
import com.gojavas.taskforce.services.GPSTracker;
import com.gojavas.taskforce.utils.Constants;
import com.gojavas.taskforce.utils.EzetapConstants;
import com.gojavas.taskforce.utils.MswipeConstants;
import com.gojavas.taskforce.utils.Utility;
import com.gojavas.taskforce.utils.UtilityScheduler;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.mswipe.wisepad.apkkit.WisePadController;
import com.mswipe.wisepad.apkkit.WisePadControllerListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import lecho.lib.hellocharts.model.PieChartData;
import lecho.lib.hellocharts.model.SliceValue;
import lecho.lib.hellocharts.view.PieChartView;

/**
 * Created by GJS280 on 14/4/2015.
 */

public class HomeActivity extends AppCompatActivity implements View.OnClickListener, WisePadControllerListener {

    private RelativeLayout mSequenceLayout, mStartLayout, mSyncLayout, mSummaryLayout, mEzetapLayout, mMSwipeLayout, mSataticsLayout, mProfileLayout, mLogoutLayout;
    private TextView mSuccessCountTextView, mFailedCountTextView, mPendingCountTextView;
    private ImageView mSyncImage;
    private PieChartView mPieChart;

    private PieChartData mPieChartData;
    private WisePadController mWisePadController;

    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    private static final String TAG = "HomeActivity";

    private static final Uri STATUS_URI = Uri.parse("content://sms");

    /**
     *  visible layout after pulling data from server using SchedularSync Service
     */
    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String message = intent.getExtras().getString(Constants.SCHEDULAR_RESPONSE_KEY);
            String errorMessage = intent.getExtras().getString(Constants.SCHEDULAR_RESPONSE_MESSAGE);
            if(message != null && message.equalsIgnoreCase(Constants.SUCCESS_RESPONSE)) {
                // Enable the layouts
                enableSyncLayout();
                if(errorMessage != null && !TextUtils.isEmpty(errorMessage)) {
                    Utility.showToast(HomeActivity.this, errorMessage);
                } else {
                    enableSequenceLayout();
                    enableStartLayout();
                    populateChart();
                }
            } else {
                Utility.showToast(HomeActivity.this, errorMessage);
                enableSyncLayout();
            }
        }
    };

    /**
     * GCM registration receiver
     */
    private BroadcastReceiver mRegistrationBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
            boolean sentToken = sharedPreferences.getBoolean(QuickstartPreferences.SENT_TOKEN_TO_SERVER, false);
//            if (sentToken) {
//                mInformationTextView.setText(getString(R.string.gcm_send_message));
//            } else {
//                mInformationTextView.setText(getString(R.string.token_error_message));
//            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        getSupportActionBar().hide();

        // Initialize crittercism
        Crittercism.initialize(getApplicationContext(), "5608f6578d4d8c0a00d07b0d"); // app-id
        Crittercism.setUsername(Utility.getDeviceId());

        String userLoggedIn = Utility.getFromSharedPrefs(HomeActivity.this, Constants.USER_LOGGED_IN);
        if(userLoggedIn == null || TextUtils.isEmpty(userLoggedIn) || userLoggedIn.equalsIgnoreCase("false")) {
            // User is not logged in
            // Go to login screen
            goToLoginScreen();
        } else {
            // Check Device date and time zone
            try {
                int dateCheck = android.provider.Settings.System.getInt(getContentResolver(), android.provider.Settings.System.AUTO_TIME);
                int timeZoneCheck = android.provider.Settings.System.getInt(getContentResolver(), Settings.System.AUTO_TIME_ZONE);
                if(dateCheck == 0) {
                    // Automatic date option is not selected
                    showDateDialog(Constants.INCORRECT_DATE_TITLE, Constants.INCORRECT_DATE_MESSAGE);
                } else if(timeZoneCheck == 0) {
                    // Automatic time zone option is not selected
                    showDateDialog(Constants.INCORRECT_TIME_ZONE_TITLE, Constants.INCORRECT_TIME_ZONE_MESSAGE);
                }
            } catch (Settings.SettingNotFoundException e) {
                e.printStackTrace();
            }

            // User is logged in
            registerViews();
            registerListeners();

            GPSTracker gpsTracker = new GPSTracker(HomeActivity.this);
            if(!gpsTracker.canGetLocation()) {
                gpsTracker.showSettingsAlert(HomeActivity.this);
            }

            if (checkPlayServices()) {
                // Start IntentService to register this application with GCM.
                Intent intent = new Intent(this, RegistrationIntentService.class);
                startService(intent);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        // If date is changed
        // Delete data and logout user
        String saveDate = Utility.getFromSharedPrefs(HomeActivity.this,Constants.LOGGED_IN_TIME);
        if(!Utility.areEqual(Long.parseLong(saveDate),System.currentTimeMillis())){
            // Logout user
            TaskForceApplication.getInstance().clearApplicationData();
            // Delete saved images
            BackupManager.clearSavedData();
            // Show login screen
            goToLoginScreen();
        }

        populateChart();
        // Register all the receivers
        LocalBroadcastManager.getInstance(this).registerReceiver(mMessageReceiver, new IntentFilter(Constants.SCHEDULAR_SYNC_ACTION));
        LocalBroadcastManager.getInstance(this).registerReceiver(mRegistrationBroadcastReceiver, new IntentFilter(QuickstartPreferences.REGISTRATION_COMPLETE));
    }

    @Override
    protected void onPause() {
        // Un-register all the receivers
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mRegistrationBroadcastReceiver);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Unregister receivers
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mMessageReceiver);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == RESULT_OK) {
            String msg = "" + data.getExtras().getString("errMsg");
            System.out.println(msg);
            switch (requestCode) {
                case WisePadController.MS_LOGIN_ACTIVITY_REQUEST_CODE:
                    String referenceId = data.getStringExtra(MswipeConstants.REFERENCE_ID);
                    String sessionTokeniser = data.getStringExtra(MswipeConstants.SESSION_TOKENISER);
                    Utility.saveToSharedPrefs(HomeActivity.this, MswipeConstants.SESSION_TOKENISER, sessionTokeniser);
                    Utility.saveToSharedPrefs(HomeActivity.this, MswipeConstants.REFERENCE_ID, referenceId);
                    boolean status = data.getExtras().getBoolean("status");
                    if(!status) {
                        Utility.showDialog(HomeActivity.this, "Error", data.getExtras().getString("errMsg"));
                    } else {
                        Utility.showDialog(HomeActivity.this, "MSwipe Login", "You are succesfully logged in");
                        System.out.println("ReferenceId: " + referenceId);
                        System.out.println("SessionTokeniser" + sessionTokeniser);
                    }
                    break;
                case AppConstants.REQ_CODE_INIT_DEVICE:
                    String title = "Initialize Device";
                    String message = "";
                    if (resultCode == EzeConstants.RESULT_SUCCESS) {
                        message = "Initialization of device is completed successfully";
                    } else {
                        message = "Initialization of device is unsuccessful";
                    }
                    Utility.showNormalAlertDialog(HomeActivity.this, title, message);
                    break;
                default:
                    break;
            }
        } else if(resultCode == RESULT_CANCELED) {
            if(data != null && data.hasExtra("newversoinavailable")){
                Log.v("Test", "Creditsaleview data is null");
                String newversionmsg = data.getExtras().getString("newversoinavailable");
                if(newversionmsg.equalsIgnoreCase("true")){
                    mWisePadController.processUpdateMswipeApplication();
                }
            }
            else if(data != null && data.hasExtra("errMsg")){
                Log.v("Test","Creditsaleview data is null");
                Utility.showDialog(HomeActivity.this, "Cancelled", data.getExtras().getString("errMsg"));

            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.home_sequence_layout:
                goToSequenceScreen();
                break;
            case R.id.home_start_layout:
                goToTabScreen();
                break;
            case R.id.home_sync_layout:
                // Pull call/sms data
                UtilityScheduler.startCallSmsService(HomeActivity.this);
                if(!Utility.isInternetConnected(HomeActivity.this)) {
                    // Backup unsynced files
                    BackupManager.getInstance().updateBackup();
                    Utility.showToast(HomeActivity.this, Constants.ERROR_INTERNET_CONNECTION);
                } else {
                    disableSyncLayout();
                    // Pull data from server
                    UtilityScheduler.startSync(HomeActivity.this);
                }
                break;
            case R.id.home_summary_layout:
                Utility.extractDatabaseFromDevice(HomeActivity.this);
                Intent summaryIntent = new Intent(HomeActivity.this, SummaryActivity.class);
                startActivity(summaryIntent);
                break;
            case R.id.home_statistics_layout:
                Intent statisticsIntent = new Intent(HomeActivity.this, StataticsAcitivity.class);
                startActivity(statisticsIntent);
                break;
            case R.id.home_profile_layout:
                Intent profileIntent = new Intent(HomeActivity.this, ProfileActivity.class);
                startActivity(profileIntent);
                break;
            case R.id.home_ezetap_layout:
                String ezetapUsername = Utility.getFromSharedPrefs(HomeActivity.this, Constants.EZETAP_USERNAME_KEY);
                EzetapPayApis.create(EzetapConstants.API_CONFIG).initializeDevice(this, AppConstants.REQ_CODE_INIT_DEVICE, ezetapUsername, null);
                break;
            case R.id.home_mswipe_layout:
//                String referenceId = Utility.getFromSharedPrefs(HomeActivity.this, MswipeConstants.REFERENCE_ID);
//                String sessionTokeniser = Utility.getFromSharedPrefs(HomeActivity.this, MswipeConstants.SESSION_TOKENISER);
//                if(referenceId != null && sessionTokeniser != null &&
//                        !TextUtils.isEmpty(referenceId) && !TextUtils.isEmpty(sessionTokeniser) &&
//                        referenceId.length() != 0 && sessionTokeniser.length() != 0) {
//                    // Logged in
//                    Utility.showNormalAlertDialog(HomeActivity.this, "Mswipe Login", "Already logged in");
//                    System.out.println("ReferenceId: " + referenceId);
//                    System.out.println("SessionTokeniser" + sessionTokeniser);
//                } else {
//                    // Not logged in
//                    // Show log in dialog

                    mWisePadController = WisePadController.sharedInstance(this, this);
                    Utility.showMswipeLoginDialog(HomeActivity.this, mWisePadController);
//                }
                break;
            case R.id.home_logout_layout:
                showLogoutAlertDialog();
                break;
            default:
                break;
        }
    }

    /**
     * Check the device to make sure it has the Google Play Services APK. If
     * it doesn't, display a dialog that allows users to download the APK from
     * the Google Play Store or enable it in the device's system settings.
     */
    private boolean checkPlayServices() {
        int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
        if (resultCode != ConnectionResult.SUCCESS) {
            if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
                GooglePlayServicesUtil.getErrorDialog(resultCode, this,
                        PLAY_SERVICES_RESOLUTION_REQUEST).show();
            } else {
                Log.i(TAG, "This device is not supported.");
                finish();
            }
            return false;
        }
        return true;
    }

    /**
     * Register all the views
     */
    private void registerViews() {
        mSequenceLayout = (RelativeLayout) findViewById(R.id.home_sequence_layout);
        mStartLayout = (RelativeLayout) findViewById(R.id.home_start_layout);
        mSyncLayout = (RelativeLayout) findViewById(R.id.home_sync_layout);
        mSyncImage = (ImageView) findViewById(R.id.home_sync_image);
        mSummaryLayout = (RelativeLayout) findViewById(R.id.home_summary_layout);
        mSataticsLayout = (RelativeLayout) findViewById(R.id.home_statistics_layout);
        mProfileLayout=(RelativeLayout)findViewById(R.id.home_profile_layout);
        mMSwipeLayout = (RelativeLayout) findViewById(R.id.home_mswipe_layout);
        mEzetapLayout = (RelativeLayout) findViewById(R.id.home_ezetap_layout);
        mLogoutLayout = (RelativeLayout) findViewById(R.id.home_logout_layout);
        mSuccessCountTextView = (TextView) findViewById(R.id.home_success_count);
        mFailedCountTextView = (TextView) findViewById(R.id.home_failed_count_textview);
        mPendingCountTextView = (TextView) findViewById(R.id.home_pending_count_textview);
        mPieChart = (PieChartView) findViewById(R.id.home_piechart);
        mPieChart.setChartRotation(270, true);
        mPieChart.setChartRotationEnabled(false);

        int count = DrsHelper.getInstance().getDrsCount();
        if(count <= 0) {
            disableSequenceLayout();
            disableStartLayout();
        }
    }

    /**
     * Register listener on all the views
     */
    private void registerListeners() {
        mSequenceLayout.setOnClickListener(this);
        mStartLayout.setOnClickListener(this);
        mSyncLayout.setOnClickListener(this);
        mSummaryLayout.setOnClickListener(this);
        mSataticsLayout.setOnClickListener(this);
        mProfileLayout.setOnClickListener(this);
        mMSwipeLayout.setOnClickListener(this);
        mEzetapLayout.setOnClickListener(this);
        mLogoutLayout.setOnClickListener(this);
    }

    /**
     * create json request for pull data api
     * @return
     */
    private JSONObject createPullRequestJson() {
        JSONObject finalJson = new JSONObject();
        String driverId = Utility.getFromSharedPrefs(HomeActivity.this, Constants.EMP_CODE_KEY);
        try {
            finalJson.put("driver_id", driverId);
            finalJson.put("entrydate", "2015-05-17"/*Utility.getCurrentDate()*/);
        } catch (JSONException je) {
            je.printStackTrace();
        }
        return finalJson;
    }

    /**
     * Populate chart
     */
    private void populateChart() {
        List<SliceValue> chartValues = new ArrayList<SliceValue>();
        Resources resources = getResources();
        int successColor = resources.getColor(R.color.success);
        int failedColor = resources.getColor(R.color.failed);
        int pendingColor = resources.getColor(R.color.pending);

        int pendingCount = DrsHelper.getInstance().getPendingDrsCount();
        int successCount = DrsHelper.getInstance().getSuccessDrsCount();
        int failedCount = DrsHelper.getInstance().getFailedDrsCount();
        int total = pendingCount + successCount + failedCount;

        mSuccessCountTextView.setText(successCount + "");
        mFailedCountTextView.setText(failedCount + "");
        mPendingCountTextView.setText(pendingCount + "");

        try {
            Float successPercentage = Float.valueOf((successCount * 100) / total);
            if(successPercentage > 0) {
                SliceValue successValue = new SliceValue(successPercentage, successColor);
                successValue.setLabel("S");
                chartValues.add(successValue);
            }
            Float failedPercentage = Float.valueOf((failedCount * 100) / total);
            if(failedPercentage > 0) {
                SliceValue failedValue = new SliceValue(failedPercentage, failedColor);
                failedValue.setLabel("F");
                chartValues.add(failedValue);
            }

            Float pendingPercentage = Float.valueOf((pendingCount * 100) / total);
            if(pendingPercentage > 0) {
                SliceValue pendingValue = new SliceValue(pendingPercentage, pendingColor);
                pendingValue.setLabel("P");
                chartValues.add(pendingValue);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        mPieChartData = new PieChartData(chartValues);
        mPieChartData.setHasCenterCircle(true);
        mPieChartData.setHasLabels(true);

        mPieChartData.setCenterText1Color(Color.WHITE);
        mPieChartData.setCenterText2Color(Color.WHITE);
        mPieChartData.setCenterText1(total + "");
        mPieChartData.setCenterText2("Total Jobs");

        mPieChart.setPieChartData(mPieChartData);
    }

    /**
     * Disable sequence layout
     */
    private void disableSequenceLayout() {
        mSequenceLayout.setEnabled(false);
        mSequenceLayout.setAlpha(0.5F);
    }

    /**
     * Enable sequence layout
     */
    private void enableSequenceLayout() {
        mSequenceLayout.setEnabled(true);
        mSequenceLayout.setAlpha(1.0F);
    }

    /**
     * Disable and dim start layout
     */
    private void disableStartLayout() {
        mStartLayout.setEnabled(false);
        mStartLayout.setAlpha(0.5F);
    }

    /**
     * Enable sequence layout
     */
    private void enableStartLayout() {
        mStartLayout.setEnabled(true);
        mStartLayout.setAlpha(1.0F);
    }

    /**
     * Disable and dim start layout
     */
    private void disableSyncLayout() {
        mSyncImage.startAnimation(AnimationUtils.loadAnimation(HomeActivity.this, R.anim.rotate));
        mSyncLayout.setEnabled(false);
//        mSyncLayout.setAlpha(0.5F);
        mSyncLayout.setBackgroundColor(getResources().getColor(R.color.app_color_a));
    }

    /**
     * Enable sequence layout
     */
    private void enableSyncLayout() {
        mSyncImage.clearAnimation();
        mSyncLayout.setEnabled(true);
//        mSyncLayout.setAlpha(1.0F);
        mSyncLayout.setBackgroundColor(getResources().getColor(R.color.app_color));
    }

    /**
     * Go to login screen
     */
    private void goToLoginScreen() {
        Intent loginIntent = new Intent(HomeActivity.this, LoginActivity.class);
        startActivity(loginIntent);
        finish();
    }

    /**
     * Go to login screen
     */
    private void goToSequenceScreen() {
        Intent sequenceIntent = new Intent(HomeActivity.this, SequenceActivity.class);
        startActivity(sequenceIntent);
    }

    /**
     * Go to tab screen
     */
    private void goToTabScreen() {
        Intent loginIntent = new Intent(HomeActivity.this, TabActivity.class);
        startActivity(loginIntent);
    }

    /**
     * Show logout alert dialog
     */
    private void showLogoutAlertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this);
        builder.setMessage(Constants.LOGOUT_MESSAGE);

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Delete database
                getApplicationContext().deleteDatabase(DatabaseHelper.DATABASE_NAME);
                // Cancel all the pending requests
                TaskForceApplication.getInstance().cancelPendingRequests();
                // Clear all the application data
                TaskForceApplication.getInstance().clearApplicationData();
                // Restart activity
                Intent intent = getIntent();
                finish();
                startActivity(intent);
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        final AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    /**
     * Show wrong date alert
     */
    private void showDateDialog(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setCancelable(false);

        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(android.provider.Settings.ACTION_DATE_SETTINGS));
                finish();
                dialog.dismiss();
            }
        });

        final AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    @Override
    public void onError(String error, int errorCode) {
        AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this);
        builder.setTitle("Mswipe Error");
        builder.setMessage(error);
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        final AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    @Override
    public void onMswipeAppInstalled() {

    }

    @Override
    public void onMswipeAppUpdated() {

    }
}
